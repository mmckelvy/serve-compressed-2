module.exports = function bundle() {
  return 'Hello world!';
}